#include <stdio.h>
#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <assert.h>
#include <sys/wait.h>
int main(int argc, char const *argv[])
{
    int broj_merenja = 100000;
    double ukupno_vreme = 0;
    for (int i = 0; i < broj_merenja; i++)
    {
        struct timeval vreme1, vreme2;
        double izmerenoVreme;
        int datoteka =  open("./datoteka.txt", O_CREAT|O_WRONLY|O_TRUNC, S_IRWXU);
        // zapocni merenje
        gettimeofday(&vreme1, NULL);

        read(datoteka,0,0);

        // zaustavi merenje
        gettimeofday(&vreme2, NULL);

        
        izmerenoVreme = (vreme2.tv_sec - vreme1.tv_sec) * 1000.0;      // sekunda u milisekundu
        izmerenoVreme += (vreme2.tv_usec - vreme1.tv_usec) / 1000.0;   
        ukupno_vreme += izmerenoVreme;
    }
    
    fprintf(stdout, "Izmereno vreme = %.20fms \n", ukupno_vreme/broj_merenja);
    
    return 0;
}
