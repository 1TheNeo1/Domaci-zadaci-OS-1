Za tacno resenje pogledati datoteka.txt

Program radi tako sto se pokrece Main, gde se preko poziva pokrecu dva programa:
1) Merenje Zamene konteksta
2) Prosecno vreme

Pri pozivu Merenja zamene konteksta dolazi do pucanja programa, pa se MAIN opet mora
pokrenuti
