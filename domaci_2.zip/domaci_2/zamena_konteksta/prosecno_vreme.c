#define _GNU_SOURCE 1

#include <stdio.h>
#include <unistd.h>
#include <sched.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <assert.h>
#include <sys/wait.h>
#include <sys/time.h>

int main(int argc, char const *argv[])
{
    FILE *fd;
    fd = fopen("datoteka.txt", "r");
    char line[256];
    float ukupno_vreme = 0.0;
    int broj_iteracija = 0;
    while (fgets(line, sizeof(line), fd)) {
        ukupno_vreme += atof(line);
        broj_iteracija++;
    }
    float prosecno_vreme = ukupno_vreme/broj_iteracija;
    printf("Prosecno vreme: %.20f \n", prosecno_vreme);
    return 0;
}
