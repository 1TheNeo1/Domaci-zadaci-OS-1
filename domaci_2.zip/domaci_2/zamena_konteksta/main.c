#define _GNU_SOURCE 1

#include <stdio.h>
#include <unistd.h>
#include <sched.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <assert.h>
#include <sys/wait.h>
#include <sys/time.h>

int main(int argc, char const *argv[])
{
    int izbor;
    int radnja = 1;
    
    while (radnja)
    {
        printf("GLAVNI PROGRAM MERENJA VREMENA! \n");
        printf("Pri pozivu Merenja zamene konteksta dolazi do pucanja programa, pa se MAIN opet mora pokrenuti \n");
        printf("1. pokreniti merac vremena \n");
        printf("2. Pogledajte prosecno vreme \n");
        printf("Vas izbor je: ");
        scanf("%d", &izbor);
        static char *argument_vrednost[]={NULL};
        if (izbor == 1)
        {
            FILE *fd;
            fd = fopen("datoteka.txt", "w");
            fclose(fd);
            int pid = fork();
            if (pid == 0)
            {
               execv("merenje_vremena_zamene_konteksta",argument_vrednost);
            }else if(pid > 0){
                wait(NULL);
            }else{
                printf("Fork nije uspeo");
            }
        }
        else if(izbor == 2)
        {
            int pid = fork();
            if (pid == 0)
            {
               execv("prosecno_vreme",argument_vrednost);
            }else if(pid > 0){
                wait(NULL);
                
            }else{
                printf("Fork nije uspeo");
            }
        }
        else{
            radnja = 0;
        } 
    }
    
    return 0;
}
