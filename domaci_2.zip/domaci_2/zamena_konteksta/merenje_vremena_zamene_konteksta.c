#define _GNU_SOURCE 1

#include <stdio.h>
#include <unistd.h>
#include <sched.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <assert.h>
#include <sys/wait.h>
#include <sys/time.h>
enum { CPU=1 };
/*
enum { CPU=1 };
cpu_set_t cpu_list;
CPU_ZERO(&cpu_list);
CPU_SET(CPU, &cpu_list);  

###Linije koda iznad predstavljaju neku vrstu bitmapa, radi odabira procerosra###
*/

int main( void )
{
  cpu_set_t cpu_list;
  CPU_ZERO(&cpu_list);
  CPU_SET(CPU, &cpu_list);
  //Ispitujem da li je sve kako treba, ako jeste nastavljam sa radom

  //fprintf(stdout,"Rsenje se nalazi u fajlu datoteka.txt \n");
  if( sched_setaffinity(getpid(), sizeof(cpu_list), &cpu_list) == 0 ){
    //Da ispitamo zamenu konteksta posluzicemo se kodu iz prvo domaceg zadatke, poslednje vezbe kad smo pravili pipe funkciju
    int broj_merenja = 1000;
    double ukupno_vreme = 0.001;
    struct timeval vreme1, vreme2;
    double izmerenoVreme;
   

        FILE * fp; 
        fp = fopen ("datoteka.txt", "a");
        
        int p1[2], p2[2];
        char buff1[100];
        char buff2[100];
        // Zapocinjemo merenje
        gettimeofday(&vreme1, NULL);
        pipe(p1);
        pipe(p2);
      
        
        int rc = fork();
        
        if (rc == 0)
        {
           for (int i =1; i < broj_merenja; i++)
        {
                dup2(p1[0], STDIN_FILENO);
                dup2(p2[1], STDOUT_FILENO);
                puts("");
                //Zavrsavamo merenje
              gettimeofday(&vreme2, NULL);
                      
              izmerenoVreme = (vreme2.tv_sec - vreme1.tv_sec) * 1000.0;      // sekunda u milisekundu
              izmerenoVreme += (vreme2.tv_usec - vreme1.tv_usec) / 1000.0;   
              ukupno_vreme += izmerenoVreme; 
              float resenje = ukupno_vreme/i;
              fprintf(fp,"%f\n", resenje);
            
        }  
        }
              
               
        
        else
        {
            int rc2 = fork();
            if (rc2 == 0)
            {
                
                fflush(stdout);
                dup2(p2[0], STDIN_FILENO);
                dup2(p1[1], STDOUT_FILENO);

                int n = read(STDIN_FILENO, buff2, sizeof buff2);
                fprintf(fp, " ");
              
               kill(rc,9);
              kill(rc2, 9);
                
            } 
            else{
              
            }

        } 
        
      

  }  
    
  else
    fprintf(stderr, "Zakljucavanje na jedno jezgro procesora nije uspelo");

  return 0;
}