#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{   
    printf("Unesite broj n=");
    int n;
    scanf("%d", &n);
    int *promenljiva =(int *) malloc(n * sizeof(int));
    int i;
    for ( i = 0; i < n; i++)
    {
      printf("\nUnesite vrednost: ");
      scanf("%d", &promenljiva[i]);
    }
    printf("\nUnete vrednosti: ");
    for ( i = 0; i < n; i++)
    {
       printf("%d ", promenljiva[i]);
    }
    printf("\n");
    return 0;
}
