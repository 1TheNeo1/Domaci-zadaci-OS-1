#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main(int argc, char const *argv[])
{   
    printf("Vrednost broja n je 100 \n");
    int n = 100; //POSTAVLJA SE VREDNOST NA 100

    int *podaci =(int *) malloc(n * sizeof(int));
    int i;
    for (i = 0; i < n; i++)
    {
        //DODAJEM VREDNOSTI SVAKOM ELEMENTU U NIZU CELIH BROJEVA
        podaci[i] = i;
    }

    int *pokazivac_na_sredinu = &podaci[50];
      //OSLOBADJAM NIZ
      free(&pokazivac_na_sredinu);
    
    srand(time(NULL)); 
    int neki_broj = rand() % 100;
    printf("Nasumican elment niza: %d \n", podaci[50]);
    


    return 0;
}
