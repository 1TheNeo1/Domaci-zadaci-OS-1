#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
    int *ceo_broj;
    ceo_broj = NULL;
    printf("%d", *ceo_broj);
    return 0;
}
