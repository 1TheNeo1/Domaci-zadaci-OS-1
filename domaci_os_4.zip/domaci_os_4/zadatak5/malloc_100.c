#include <stdio.h>
#include <stdlib.h>



int main(int argc, char const *argv[])
{   
    printf("Vrednost broja n je 100 \n");
    int n = 100; //POSTAVLJA SE VREDNOST NA 100

    int *podaci =(int *) malloc(n * sizeof(int));
    podaci[100] = 0;


    return 0;
}
