#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    int pv = fork();
    if (pv < 0) {
        // Ukoliko fork() ne uspe, ispisi poruku o gresci i izadji
        fprintf(stderr, "fork nije uspeo\n");        
        exit(1);
    } else if (pv == 0) {
        printf("Zdravo\n");
    } else {
        int wait_pv = wait(NULL);
        printf("Dovidjenja \n");
    }
    return 0;
}