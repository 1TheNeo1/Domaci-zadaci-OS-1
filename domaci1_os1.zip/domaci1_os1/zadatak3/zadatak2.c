#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

// DRUGIO NACIN DA SE DETE PRVO IZVRSIJE DA SE AND RODITELJEM POZOVE SLEEP. 
// OVO VAZI SAMO UKOLI SMO SIGURNO DA CE SE fork() UVEK IZVRSITI

int main(int argc, char *argv[]) {
    int pv = fork();
    if (pv < 0) {
        // Ukoliko fork() ne uspe, ispisi poruku o gresci i izadji
        fprintf(stderr, "fork nije uspeo\n");        
        exit(1);
    } else if (pv == 0) {
        printf("Zdravo\n");
    } else {
        sleep(1); 
        printf("Dovidjenja \n");
    }
    return 0;
}