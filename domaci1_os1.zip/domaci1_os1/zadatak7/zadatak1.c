#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <assert.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    int pv = fork();
    if (pv < 0) {
      // Ukoliko fork() ne uspe, ispisi poruku o gresci i izadji
      fprintf(stderr, "Fork nije uspeo\n");
      exit(1);
    } else if (pv == 0) {
      char buffer[100];
      close(STDOUT_FILENO); 
      sprintf(buffer, "Ja sam dete, i zatvorio sam standardni izlaz");
	   
    } else {
      printf("Ja sam roditelj\n");
    }
    return 0;
}