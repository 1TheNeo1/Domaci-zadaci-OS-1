#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <assert.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    int datoteka =  open("./datoteka.txt", O_CREAT|O_WRONLY|O_TRUNC, S_IRWXU);
    int pv = fork();
    if (pv < 0) {
      fprintf(stderr, "Fork nije uspeo\n");
      exit(1);
    } else if (pv == 0) {
      close(STDOUT_FILENO); // Zatvaramo standardni izlaz - STDOUT
      char text1[50] =  "Zdravo ja sam dete\n";
      write(datoteka, text1, strlen(text1));
      
    } else {
      close(STDOUT_FILENO);
      char text2[50] =  "zdravo ja sam roditelj\n";
      write(datoteka, text2, strlen(text2));
    }
    close(datoteka); 
    return 0;
}