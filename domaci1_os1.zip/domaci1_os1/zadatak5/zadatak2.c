#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    int pv = fork();
    if (pv < 0) {
        // Ukoliko fork() ne uspe, ispisi poruku o gresci i izadji
        fprintf(stderr, "fork nije uspeo\n");        
        exit(1);
    } else if (pv == 0) {
        int wait_pv = wait(NULL);
        printf("Ja sam dete, vrendnost koju vraca wait() je %d \n", wait_pv);
    } else {
        printf("Ja sam roditelj, dete ceka da se izvrsim\n");
    }
    return 0;
}