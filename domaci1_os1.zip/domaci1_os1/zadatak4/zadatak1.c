#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <assert.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    int pv = fork();
    if (pv < 0) {
      // Ukoliko fork() ne uspe, ispisi poruku o gresci i izadji
      fprintf(stderr, "Fork nije uspeo\n");
      exit(1);
    } else if (pv == 0) {
      char *nizargs[2];
      nizargs[0] = "/bin/ls";    
      nizargs[1] = NULL;            
      execvp(nizargs[0], nizargs);
    } else {
      int wait_pv = wait(NULL);
	   assert(wait_pv >= 0);
    }
    return 0;
}