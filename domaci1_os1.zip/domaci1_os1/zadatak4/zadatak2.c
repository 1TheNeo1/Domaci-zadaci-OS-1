#include <stdio.h>

int main(int argc, char const *argv[])
{
    printf("JA ne radim nista sluzim kao test za zadatatak1");
    return 0;
}
