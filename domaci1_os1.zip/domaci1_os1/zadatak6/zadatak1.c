#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    int pv = fork();
    int status;
    if (pv < 0) {
        // Ukoliko fork() ne uspe, ispisi poruku o gresci i izadji
        fprintf(stderr, "fork nije uspeo\n");        
        exit(1);
    } else if (pv == 0) {
        printf("Ja sam dete, roditelj ceka da se izvrsim\n");
    } else {
        int wait_pv = waitpid(pv,&status,0);
        printf("Ja sam roditelj, vrendnost koju vraca wait() je %d \n", wait_pv);
    }
    return 0;
}