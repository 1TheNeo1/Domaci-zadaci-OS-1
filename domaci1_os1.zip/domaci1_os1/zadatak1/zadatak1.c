#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int povratna_vrednost = fork(); 
    int x = 0;
    if (povratna_vrednost < 0) {
        fprintf(stderr, "Fork nije uspeo\n");
        exit(1);
    } else if (povratna_vrednost == 0) { 
        //dete
        printf("%d", x);
    } else {
        //roditelj
    }
    return 0;
}
