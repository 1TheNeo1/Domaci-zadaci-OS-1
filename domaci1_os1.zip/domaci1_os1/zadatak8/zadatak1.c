#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <assert.h>
#include <sys/wait.h>

int main() {
    int p1[2], p2[2];
    pipe(p1);
    pipe(p2);

    char buff1[100];
    char buff2[100];
    int rc = fork();
    if (rc == 0)
    {
        printf("pokrecem proces prvog deteta sa pid-om : (%d)\n", (int)getpid());
        dup2(p1[0], STDIN_FILENO);
        dup2(p2[1], STDOUT_FILENO);
        puts("zdravo ja sam prvo dete, iako ja ne otvaram datoteku ovo ce se ispisati u fajlu 'datoteka.txt'");
    }
    else
    {
        int rc2 = fork();
        if (rc2 == 0)
        {
            int fd2 = open("datoteka.txt", O_CREAT|O_WRONLY|O_TRUNC, S_IRWXU);
            printf("pokrecem proces drugog deteta sa pid-om : (%d)\n", (int)getpid());
            fflush(stdout);
            dup2(p2[0], STDIN_FILENO);
            dup2(p1[1], STDOUT_FILENO);

            int n = read(STDIN_FILENO, buff2, sizeof buff2);
            write(fd2, buff2, n);
        }
        else
        {
            printf("Pozdrav, ja sam roditelj sa pid-om: (%d)\n", (int)getpid());
            waitpid(rc, &rc, 0);
            waitpid(rc2, &rc2, 0);
        }
    }
    return 0;
}