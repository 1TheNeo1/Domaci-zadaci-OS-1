#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include "biblioteka_niti.h"
#include <semaphore.h>
// Napravite semafor. Uradite to tako da dete ispisuje svoju poruku
// izmedju dve poruke roditelja.

sem_t s; 

void *child(void *arg) {
    printf("dete\n");
    // ovde ubacite semafor
    
    sem_post(&s);
    return NULL;
}

int main(int argc, char *argv[]) {
    pthread_t p;
    printf("roditelj: pocetak\n");
    // ovde incijalizujte semafor
    sem_init(&s, 0, 0);
    Pthread_create(&p, NULL, child, NULL);
    sem_wait(&s);
    // ovde iskoristite semafor
    printf("roditelj: kraj\n");
    return 0;
}

