#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include "biblioteka_niti.h"

// Ukoliko ovo uradite ispravno, svako dete treba da odstampa svoju "pre" poruku pre nego
// sto bilo ko odstampa svoju "posle" poruku. 

// Da biste ovo uradili na ispravan nacin, verovatno su vam potrebna dva semafora, kao i neki
// indedzeri kako biste pratili razvoj stvari. Probajte da napravite svoju implementaciju.

typedef struct __barijera_t {
    // ovde dodajte semafore i ostale potrebne informacije
    sem_t s1, s2;
    int broj_niti;
    int brojac;
} barijera_t;


// jednostavna barijera koju koristimo u ovom programu
barijera_t b;

void barijera_init(barijera_t *b, int broj_niti) {
    // ovde ide kod za inicijalizaiju
    sem_init(&b->s1, 0, 1);
    sem_init(&b->s2, 0, 0);
   b->broj_niti = broj_niti;
   b->brojac = 0;
    
}

void barijera(barijera_t *b) {
    // ovde ide kod same barijere
    sem_wait(&b->s1);
	b->brojac = b->brojac + 1;
	sem_post(&b->s1);

    if(b->brojac==b->broj_niti)
    {
        sem_post(&b->s2);
    }
		
	sem_wait(&b->s2);
	sem_post(&b->s2);    
}
//
// KOD KOJI JE DAT ISPOD NEMOJTE MENJATI
//
typedef struct __tinfo_t {
    int thread_id;
} tinfo_t;

void *child(void *arg) {
    tinfo_t *t = (tinfo_t *) arg;
    printf("dete %d: pre\n", t->thread_id);
    barijera(&b);
    printf("dete %d: posle\n", t->thread_id);
    return NULL;
}


// program pokrenite sa jednim argumentom koji ukazuje na broj niti koje zelite da kreirate (1 ili vise)
int main(int argc, char *argv[]) {
    assert(argc == 2);
    int broj_niti = atoi(argv[1]);
    assert(broj_niti > 0);

    pthread_t p[broj_niti];
    tinfo_t t[broj_niti];

    printf("roditelj: pocetak\n");
    barijera_init(&b, broj_niti);
    
    int i;
    for (i = 0; i < broj_niti; i++) {
	t[i].thread_id = i;
	Pthread_create(&p[i], NULL, child, &t[i]);
    }

    for (i = 0; i < broj_niti; i++) 
	Pthread_join(p[i], NULL);

    printf("roditelj: kraj\n");
    return 0;
}

