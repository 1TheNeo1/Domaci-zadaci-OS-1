#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "biblioteka_niti.h"
#include <semaphore.h>
//
// Dodajte svoj kod u strukturu i funkcije date ispod.
//

typedef struct __rwlock_t {
    sem_t brava;    
    sem_t writebrava;
    int citaoci;
} rwlock_t;


void rwlock_init(rwlock_t *rw) {
    rw->citaoci = 0;
    sem_init(&rw->brava, 0, 1);
    sem_init(&rw->writebrava, 0, 1);

}

void rwlock_acquire_readlock(rwlock_t *rw) {
    sem_wait(&rw->brava);
    rw->citaoci++;
    if (rw->citaoci == 1)
    {
        sem_wait(&rw->writebrava);
    }
    sem_post(&rw->brava);
    
}

void rwlock_release_readlock(rwlock_t *rw) {
    sem_wait(&rw->brava);
    rw->citaoci--;
    if (rw->citaoci == 0)
    {
        sem_post(&rw->writebrava);
    }
    
    sem_post(&rw->brava);
    sem_post(&rw->writebrava); 
}

void rwlock_acquire_writelock(rwlock_t *rw) {
    sem_wait(&rw->writebrava);
}

void rwlock_release_writelock(rwlock_t *rw) {
    sem_post(&rw->writebrava);
}

//
// KOD DAT ISPOD NEMOJTE MENJATI.
// 

int broj_iteracija;
int vrednost = 0;

rwlock_t lock;

void *citalac(void *arg) {
    int i;
    for (i = 0; i < broj_iteracija; i++) {
	rwlock_acquire_readlock(&lock);
	printf("procitano %d\n", vrednost);
	rwlock_release_readlock(&lock);
    }
    return NULL;
}

void *pisac(void *arg) {
    int i;
    for (i = 0; i < broj_iteracija; i++) {
	rwlock_acquire_writelock(&lock);
	vrednost++;
	printf("upisano %d\n", vrednost);
	rwlock_release_writelock(&lock);
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    assert(argc == 4);
    int broj_citalaca = atoi(argv[1]);
    int broj_pisaca = atoi(argv[2]);
    broj_iteracija = atoi(argv[3]);

    pthread_t pr[broj_citalaca], pw[broj_pisaca];

    rwlock_init(&lock);

    printf("pocetak\n");

    int i;
    for (i = 0; i < broj_citalaca; i++)
	Pthread_create(&pr[i], NULL, citalac, NULL);
    for (i = 0; i < broj_pisaca; i++)
	Pthread_create(&pw[i], NULL, pisac, NULL);

    for (i = 0; i < broj_citalaca; i++)
	Pthread_join(pr[i], NULL);
    for (i = 0; i < broj_pisaca; i++)
	Pthread_join(pw[i], NULL);

    printf("kraj: vrednost %d\n", vrednost);

    return 0;
}

