#include <stdio.h>
#include <unistd.h>
#include "biblioteka_niti.h"
#include <semaphore.h>
// Ukoliko ovo uradite ispravno, oba deteta treba da odstampaju svoju "pre" poruku pre nego
// sto drugo dete odstampa svoju "posle" poruku. 

sem_t s1, s2;

void *dete_1(void *arg) {
    printf("dete 1: pre\n");
    // sta ide ovde?
    sem_post(&s1);
    sem_wait(&s2);
    printf("dete 1: posle\n");
    return NULL;
}

void *dete_2(void *arg) {
    printf("dete 2: pre\n");
    // sta ide ovde?
    sem_post(&s2);
    sem_wait(&s1);
    printf("dete 2: posle\n");
    return NULL;
}

int main(int argc, char *argv[]) {
    pthread_t p1, p2;
    printf("roditelj: pocetak\n");
    // ovde inicijalizujte semafore
    sem_init(&s1, 0, 0);
    sem_init(&s2, 0, 1);
    Pthread_create(&p1, NULL, dete_1, NULL);
    Pthread_create(&p2, NULL, dete_2, NULL);
    Pthread_join(p1, NULL);
    Pthread_join(p2, NULL);
    printf("roditelj: kraj\n");
    return 0;
}

