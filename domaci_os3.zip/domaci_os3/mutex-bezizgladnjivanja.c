#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include "biblioteka_niti.h"
#include <semaphore.h>
//
// Ovde treba da ubacite malo vise koda. Dodajte svoj kod u strukturu i funkcije date ispod.
// Pokazite da nit nece biti izgladnjena kada pokusa da uzme mutex koji ste napravili.
//

typedef struct __moj_mutex_t {
    sem_t mutex;
} moj_mutex_t;

void moj_mutex_init(moj_mutex_t *m) {
    sem_init(&m->mutex, 0, 1);
}

void moj_mutex_acquire(moj_mutex_t *m) {
    sem_wait(&m->mutex);
}

void moj_mutex_release(moj_mutex_t *m) {
    sem_post(&m->mutex);
}

moj_mutex_t m;
int broj_iteracija;
void *worker(void *arg) {
    moj_mutex_acquire(&m);
    broj_iteracija++;
    printf("Iteracija %d. \n", broj_iteracija);
    moj_mutex_release(&m);
    return NULL;
}

int main(int argc, char *argv[]) {
    assert(argc == 2);
    int broj_niti = atoi(argv[1]);
    pthread_t pr[broj_niti];
    moj_mutex_init(&m);

    printf("roditelj: pocetak\n");
    int i;
    for (i = 0; i < broj_niti; i++)
	    Pthread_create(&pr[i], NULL, worker, NULL);
    for (i = 0; i < broj_niti; i++)
	    Pthread_join(pr[i], NULL);
    printf("broj iteracija: %d\n",broj_iteracija);
    printf("roditelj: kraj\n");
    return 0;
}

